library(cluster)
library(CatEncoders)
library(stringr)
library(DescTools)
library(readr)
library(plyr)
library(dplyr)
library(caret)

data_import <- read_csv(file.choose())

names(data_import)<-str_replace_all(names(data_import), c(" " = "_" , "," = "" ))


df_details <- function(df){
  feature_names <- names(df)
  length_feature <- length(feature_names)
  feature_row_count <- c()
  feature_null_check <- c()
  for (i in 1:length_feature){
    feature_row_count[i] <- sapply(data_import, function(x) length(unique(x)))[i]
    feature_null_check[i] <- is.null(df[i])
  }
  df <- data.frame("feature_names" = feature_names,
                   "feature_row_count" = feature_row_count,
                   "feature_null_check" = feature_null_check)
  return(df)
}

data_frame_output <- df_details(data_import)

#by analysing the output we can remove columns which has only 2 unique values
#and columns which has 90% same data. These will not provide any value to the
#model
#df_filter <- data_import[,c(5,6,7,9,12,13,22,24,25,26,27,28,29,30)]

df_filter <- data_import
str(data_import)

#label encoding, converting character to numeric data
df_filter$Customer	 <- as.numeric(as.factor(df_filter$Customer))
df_filter$State	 <- as.numeric(as.factor(df_filter$State))
df_filter$Response	 <- as.numeric(as.factor(df_filter$Response))
df_filter$Coverage	 <- as.numeric(as.factor(df_filter$Coverage))
df_filter$Education	 <- as.numeric(as.factor(df_filter$Education))
df_filter$Effective_To_Date	 <- as.numeric(as.factor(df_filter$Effective_To_Date))
df_filter$EmploymentStatus	 <- as.numeric(as.factor(df_filter$EmploymentStatus))
df_filter$Gender	 <- as.numeric(as.factor(df_filter$Gender))
df_filter$Location_Code	 <- as.numeric(as.factor(df_filter$Location_Code))
df_filter$Marital_Status	 <- as.numeric(as.factor(df_filter$Marital_Status))
df_filter$Policy_Type	 <- as.numeric(as.factor(df_filter$Policy_Type))
df_filter$Policy	 <- as.numeric(as.factor(df_filter$Policy))
df_filter$Renew_Offer_Type	 <- as.numeric(as.factor(df_filter$Renew_Offer_Type))
df_filter$Sales_Channel	 <- as.numeric(as.factor(df_filter$Sales_Channel))
df_filter$Vehicle_Class	 <- as.numeric(as.factor(df_filter$Vehicle_Class))
df_filter$Vehicle_Size	 <- as.numeric(as.factor(df_filter$Vehicle_Size))

boxplot(df_filter)

nrow(unique(df_filter))
df_filter["Customer_Lifetime_Value"] <- Winsorize(df_filter$Customer_Lifetime_Value, probs = c(0.00, 0.90))
names(df_filter)

#rm(list=ls())

# Normalize the data
normalized_data <- scale(df_filter[,]) # Excluding the university name

summary(normalized_data)

# Elbow curve to decide the k value
twss <- NULL
for (i in 2:8) {
  twss <- c(twss, kmeans(normalized_data, centers = i)$tot.withinss)
}
twss

# Look for an "elbow" in the scree plot
plot(2:8, twss, type = "b", xlab = "Number of Clusters", ylab = "Within groups sum of squares")
title(sub = "K-Means Clustering Scree-Plot")


# 3 Cluster Solution
fit <- kmeans(normalized_data, 3) 
str(fit)
fit$cluster
final <- data.frame(fit$cluster, df_filter) # Append cluster membership

aggregate(data_import[, 1:24], by = list(fit$cluster), FUN = mean)





