library(DescTools)
library(readr)
library(plyr)

#loading the csv file
input <- read_csv(file.choose())
names(input)

#renaming column name to correct format
names(input)[names(input) == "X1"] <- "States"

#checking for null values
is.null(input['States'])
is.null(input['Murder'])
is.null(input['Assault'])
is.null(input['UrbanPop'])
is.null(input['Rape'])

#checking for duplicate records
nrow(input)
nrow(unique(input))
#there are no duplicates in the dataset

#plotting boxplots to find outliers for numeric data
boxplot(input$Murder)
boxplot(input$Assault)
boxplot(input$UrbanPop)
boxplot(input$Rape)

#outliers are present in the last column. handling outlier with
#winsorizor technique
df_copy <- data.frame(input)
df_copy['Rape'] <- Winsorize(df_copy$Rape, probs = c(0.00, 0.95))
boxplot(df_copy$Rape)

df_no_outliers <- data.frame(df_copy)

#removing columns which do not give any meaning to our model, states in this case
df_no_states <- df_no_outliers[,c(2:5)]

# Normalize the data
normalized_data <- scale(df_no_states[,])

# Elbow curve to decide the k value
twss <- NULL
for (i in 2:8) {
  twss <- c(twss, kmeans(normalized_data, centers = i)$tot.withinss)
}
twss

# Look for an "elbow" in the scree plot
plot(2:8, twss, type = "b", xlab = "Number of Clusters", ylab = "Within groups sum of squares")
title(sub = "K-Means Clustering Scree-Plot")


# 3 Cluster Solution
fit <- kmeans(normalized_data, 3) 
str(fit)
fit$cluster
final <- data.frame(fit$cluster, mydata) # Append cluster membership

aggregate(df_no_states[, 1:4], by = list(fit$cluster), FUN = mean)





