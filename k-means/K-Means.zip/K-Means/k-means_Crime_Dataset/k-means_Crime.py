# -*- coding: utf-8 -*-
"""
Created on Wed Apr  7 14:40:17 2021

@author: Avinash
"""

#Importing libraries
import pandas as pd
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import preprocessing
import pylab

#Load the dataset
crime = pd.read_csv("C:\\Users\\Avinash\\Desktop\\Assignments\\Hierarchical_clustering\\crime_data.csv")

#To display the columns
crime.columns

#To display the information
crime.info()
#crime.rename( columns={'Unnamed: 0':'Country'}, inplace=True ) #To name the unnamed column 
#In the given dataset, first column is unnamed. hence given suitable column name

#Dropping the unwanted columns which we do not need for model
crime1 = crime.drop(["Unnamed: 0"], axis=1)

#To check duplicate rows
crime1.duplicated().sum() #No duplicate rows in the dataset

#To check missing values in the dataset
crime1.isna().sum() #No missing values/NAN values in the dataset

# To count the number of outliers in the columns
Q1 = crime1.quantile(0.25)
Q3 = crime1.quantile(0.75)
IQR = Q3 - Q1
count=((crime1 < (Q1 - 1.5 * IQR)) | (crime1 > (Q3 + 1.5 * IQR))).sum()
count

#To check outliers using boxplot
plt.boxplot(crime1.Rape)

IQR = crime1['Rape'].quantile(0.75) - crime1['Rape'].quantile(0.25)
IQR
lower_limit = crime1['Rape'].quantile(0.25) - (IQR * 1.5)
lower_limit
upper_limit = crime1['Rape'].quantile(0.75) + (IQR * 1.5)
upper_limit

#To remove outliers by winsorise method
df_winsorize = crime1.copy(deep=True)
stats.mstats.winsorize(a=df_winsorize['Rape'], limits=(0, 0.04), inplace=True)
df_winsorize.boxplot(column=['Rape'])

#Normalisation
normalize = preprocessing.MinMaxScaler()
normalize_array = normalize.fit_transform(crime1)
df_norm = pd.DataFrame(normalize_array,columns=list(crime1))
df_norm



from sklearn.cluster import	KMeans

###### scree plot or elbow curve ############
#k-means algorithm where we predifine the number of clusters
TWSS = []
k = list(range(2, 9))

for i in k:
    kmeans = KMeans(n_clusters = i)
    kmeans.fit(df_norm)
    TWSS.append(kmeans.inertia_)
    
TWSS
# Scree plot 
plt.plot(k, TWSS, 'ro-');plt.xlabel("No_of_Clusters");plt.ylabel("total_within_SS")

# Selecting 3 clusters from the above scree plot which is the optimum number of clusters 
model = KMeans(n_clusters = 3)
model.fit(df_norm)

model.labels_ # getting the labels of clusters assigned to each row 
mb = pd.Series(model.labels_)  # converting numpy array into pandas series object 
crime1['clust'] = mb # creating a  new column and assigning it to new column 

crime1.head()
df_norm.head()

crime1 = crime1.iloc[:,[4,0,1,2,3]]
crime1.head()

#Applying aggregate function mean to each column
crime1.iloc[:, 1:].groupby(crime1.clust).mean()

crime1.to_csv("Kmeans_crime.csv", encoding = "utf-8")

import os
os.getcwd()
