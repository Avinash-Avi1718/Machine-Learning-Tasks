library(DescTools)
library(readr)
library(plyr)

#loading the csv file
input <- read_csv(file.choose())
names(input)

#checking for null values
is.null(input['Premiums Paid'])
is.null(input['Age'])
is.null(input['Days to Renew'])
is.null(input['Claims made'])
is.null(input['Income'])

#checking for duplicate records
nrow(input)
nrow(unique(input))
#there are no duplicates in the dataset

#plotting boxplots to find outliers for numeric data
boxplot(input$`Premiums Paid`)
boxplot(input$Age)
boxplot(input$`Days to Renew`)
boxplot(input$`Claims made`)
boxplot(input$`Income`)

#outliers are present in the last column. handling outlier with
#winsorizor technique
input['Premiums Paid'] <- Winsorize(input$`Premiums Paid`, probs = c(0.00, 0.95))
boxplot(input$`Premiums Paid`)

input['Claims made'] <- Winsorize(input$`Claims made`, probs = c(0.00, 0.90))
boxplot(input$`Claims made`)

# Normalize the data
normalized_data <- scale(input[,])

# Elbow curve to decide the k value
twss <- NULL
for (i in 2:8) {
  twss <- c(twss, kmeans(normalized_data, centers = i)$tot.withinss)
}
twss

# Look for an "elbow" in the scree plot
plot(2:8, twss, type = "b", xlab = "Number of Clusters", ylab = "Within groups sum of squares")
title(sub = "K-Means Clustering Scree-Plot")


# 3 Cluster Solution
fit <- kmeans(normalized_data, 3) 
str(fit)
fit$cluster
final <- data.frame(fit$cluster, mydata) # Append cluster membership

aggregate(input[, 1:5], by = list(fit$cluster), FUN = mean)





