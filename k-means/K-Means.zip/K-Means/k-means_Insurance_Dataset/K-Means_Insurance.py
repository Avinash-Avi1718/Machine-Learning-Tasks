# -*- coding: utf-8 -*-
"""
Created on Mon Apr 12 20:36:36 2021

@author: Avinash
"""

#importing required libraries

import pandas as pd

import matplotlib.pylab as plt

from scipy import stats

from sklearn.cluster import	KMeans



#loading the data to dataframe

df = pd.read_csv("C:\\Users\\Avinash\\Desktop\\Assignments\\k-means\\Insurance Dataset.csv")



#loading summary about the dataframe to analyse

df.describe()

df.info()

list(df)



#checking for duplicate records in dataset

df_copy = df.copy(deep = True)

df_copy.shape

df_unique = pd.DataFrame.drop_duplicates(df_copy)

df_unique.shape



#checking for any outliers by plotting boxplots on numeric data

plt.boxplot(df['Premiums Paid'])

plt.boxplot(df['Age'])

plt.boxplot(df['Days to Renew'])

plt.boxplot(df['Claims made'])

plt.boxplot(df['Income'])



#winsorizing the outliers

df_temp = df.copy(deep=True)

stats.mstats.winsorize(a=df_temp['Premiums Paid'], limits=(0.00, 0.05), inplace=True)

plt.boxplot(df_temp['Premiums Paid'])



stats.mstats.winsorize(a=df_temp['Claims made'], limits=(0.00, 0.10), inplace=True)

plt.boxplot(df_temp['Claims made'])



df_no_outliers = df_temp.copy(deep=True)



df_copy = df_no_outliers.copy(deep=True)

df_copy.info()



# Normalization function 

def norm_func(i):

    x = (i - i.min())	/ (i.max() - i.min())

    return (x)



# Normalized data frame (considering the numerical part of data)

df_norm = norm_func(df_copy.iloc[:, :])



###### scree plot or elbow curve ############

TWSS = []

k = list(range(2, 9))



for i in k:

    kmeans = KMeans(n_clusters = i)

    kmeans.fit(df_norm)

    TWSS.append(kmeans.inertia_)

    

TWSS

# Scree plot 

plt.plot(k, TWSS, 'ro-');plt.xlabel("No_of_Clusters");plt.ylabel("total_within_SS")



# Selecting 4 clusters from the above scree plot which is the optimum number of clusters 

model = KMeans(n_clusters = 4)

model.fit(df_norm)



model.labels_ # getting the labels of clusters assigned to each row 

mb = pd.Series(model.labels_)  # converting numpy array into pandas series object 

df_copy['clust'] = mb # creating a  new column and assigning it to new column 



df_copy.head()

df_norm.head()



df_copy = df_copy.iloc[:,[5,0,1,2,3,4]]

df_copy.head()



df_copy.iloc[:, 1:6].groupby(df_copy.clust).mean()



df_copy.to_csv("insurance dataset.csv", encoding = "utf-8")



import os

os.getcwd()
