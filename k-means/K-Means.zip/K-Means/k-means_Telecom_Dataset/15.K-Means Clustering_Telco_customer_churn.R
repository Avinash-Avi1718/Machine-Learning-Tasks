library(DescTools)
library(readr)
library(readxl)
library(stringr)
library(plyr)

#loading the csv file
input <- read_excel(file.choose(), sheet = 'Telco_Churn')
names(input)

#checking for duplicate records
nrow(input)
nrow(unique(input))
#there are no duplicates in the dataset

names(input)<-str_replace_all(names(input), c(" " = "_" , "," = "" ))

df_details <- function(df){
  feature_names <- names(df)
  length_feature <- length(feature_names)
  feature_row_count <- c()
  feature_max_unique <- c()
  feature_null_check <- c()
  for (i in 1:length_feature){
    frequency_vector <- count(df, feature_names[i])
    feature_row_count[i] <- nrow(frequency_vector[1])
    feature_max_unique[i] <- max(frequency_vector[2])
    feature_null_check[i] <- is.null(df[i])
  }
  df <- data.frame("feature_names" = feature_names,
                   "feature_row_count" = feature_row_count,
                   "feature_max_unique" = feature_max_unique,
                   "feature_null_check" = feature_null_check)
  return(df)
}

data_frame_output <- df_details(input)

#by analysing the output we can remove columns which has only 2 unique values
#and columns which has 90% same data. These will not provide any value to the
#model
df_filter <- input[,c(5,6,7,9,13,22,25,26,27,28,29,30)]

#label encoding, converting character to numeric data
df_filter$Offer <- as.numeric(as.factor(df_filter$Offer))
df_filter$Internet_Type <- as.numeric(as.factor(df_filter$Internet_Type))
df_filter$Contract <- as.numeric(as.factor(df_filter$Contract))
df_filter$Payment_Method <- as.numeric(as.factor(df_filter$Payment_Method))

nrow(unique(df_filter))
df_filter["Total_Revenue"] <- Winsorize(df_filter$Total_Revenue, probs = c(0.00, 0.90))
names(df_filter)
boxplot(df_filter["Number_of_Referrals"])
boxplot(df_filter["Offer"])
boxplot(df_filter[,3])
boxplot(df_filter[,4])
boxplot(df_filter[,5])
boxplot(df_filter[,6])
boxplot(df_filter[,7])
boxplot(df_filter[,8])
boxplot(df_filter[,9])
boxplot(df_filter[,10])
boxplot(df_filter[,11])
boxplot(df_filter[,12])
boxplot(df_filter[,13])
boxplot(df_filter[,14])

names(df_filter)
#rm(list=ls())

df_filter

# Normalize the data
normalized_data <- scale(df_filter[,])

# Elbow curve to decide the k value
twss <- NULL
for (i in 2:8) {
  twss <- c(twss, kmeans(normalized_data, centers = i)$tot.withinss)
}
twss

# Look for an "elbow" in the scree plot
plot(2:8, twss, type = "b", xlab = "Number of Clusters", ylab = "Within groups sum of squares")
title(sub = "K-Means Clustering Scree-Plot")


# 3 Cluster Solution
fit <- kmeans(normalized_data, 3) 
str(fit)
fit$cluster
final <- data.frame(fit$cluster, df_filter) # Append cluster membership

aggregate(df_filter[, 1:12], by = list(fit$cluster), FUN = mean)


