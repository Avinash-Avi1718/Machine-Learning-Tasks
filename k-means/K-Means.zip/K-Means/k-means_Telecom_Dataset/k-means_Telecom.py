# -*- coding: utf-8 -*-
"""
Created on Wed Apr  7 15:09:13 2021

@author: Avinash
"""

import pandas as pd
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import preprocessing
from sklearn.preprocessing import OneHotEncoder
import pylab
from sklearn.preprocessing import LabelEncoder

Telecom = pd.read_excel("C:\\Users\\Avinash\\Desktop\\Assignments\\Hierarchical_clustering\\Telco_customer_churn.xlsx", sheet_name = 'Telco_Churn')
Telecom.columns #To display column names
Telecom.shape

Telecom1 = Telecom[['Number of Referrals','Tenure in Months','Offer', 'Avg Monthly Long Distance Charges','Internet Type','Avg Monthly GB Download','Contract','Payment Method','Monthly Charge','Total Charges','Total Long Distance Charges','Total Revenue']]


#Label encoding to the categorical columns
lb_make = LabelEncoder()

df_copy = Telecom1.copy(deep=True)

df_copy['Offer'] = lb_make.fit_transform(df_copy['Offer'])

df_copy['Internet Type'] = lb_make.fit_transform(df_copy['Internet Type'])

df_copy['Contract'] = lb_make.fit_transform(df_copy['Contract'])

df_copy['Payment Method'] = lb_make.fit_transform(df_copy['Payment Method'])

df_encoded = df_copy.copy()

#Normalisation
normalize = preprocessing.MinMaxScaler()
normalize_array = normalize.fit_transform(df_encoded)
df_norm = pd.DataFrame(normalize_array,columns=list(df_encoded))
df_norm

from sklearn.cluster import	KMeans

###### scree plot or elbow curve ############
#k-means algorithm where we predifine the number of clusters
TWSS = []
k = list(range(2, 9))

for i in k:
    kmeans = KMeans(n_clusters = i)
    kmeans.fit(df_norm)
    TWSS.append(kmeans.inertia_)
    
TWSS
# Scree plot 
plt.plot(k, TWSS, 'ro-');plt.xlabel("No_of_Clusters");plt.ylabel("total_within_SS")

# Selecting 3 clusters from the above scree plot which is the optimum number of clusters 
model = KMeans(n_clusters = 3)
model.fit(df_norm)

model.labels_ # getting the labels of clusters assigned to each row 
mb = pd.Series(model.labels_)  # converting numpy array into pandas series object 
Telecom1['clust'] = mb # creating a  new column and assigning it to new column 

Telecom1.head()
df_norm.head()

Telecom1 = Telecom1.iloc[:,[4,0,1,2,3]]
Telecom1.head()

#Applying aggregate function mean to each column
Telecom1.iloc[:, 1:].groupby(Telecom1.clust).mean()

Telecom1.to_csv("Kmeans_Telecom.csv", encoding = "utf-8")

import os
os.getcwd()

